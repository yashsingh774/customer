import 'package:flutter/material.dart';

class CustomColors {
  static var COLOR_FB = Color(0xFF3b5998);
  static var COLOR_GREEN = Color(0xFF01a550);
  static var EDIT_PROFILE_PIC_FIRST_GRADIENT = Color(0xFF6713D2);
  static var EDIT_PROFILE_PIC_SECOND_GRADIENT = Color(0xFFCC208E);
}
