class FoodApi {
 
   static String rootUrl = 'http://192.168.29.30:8000';
//  static String rootUrl = 'https://mrecho.in';
  static String baseApi = rootUrl + '/api/v1';
}

